﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using Microsoft.ServiceBus;
using System.Configuration;
using System.IO;

namespace EventDrivenApp
{
    public class ServiceBusMapping
    {
        #region Fields
        static string ServiceBusConnectionString = ConfigurationManager.AppSettings["Microsoft.ServiceBus.ConnectionString"];
        static string TopicName = ConfigurationManager.AppSettings["TopicName"];
        static string SubsNameAllMessages = ConfigurationManager.AppSettings["SubsNameAllMessages"];
        static string SubsNameColorBlueSize10Orders = ConfigurationManager.AppSettings["SubsNameColorBlueSize10Orders"];
        static string SubsNameHighPriorityOrders = ConfigurationManager.AppSettings["SubsNameHighPriorityOrders"];        
        #endregion


        public static void EnableServiceBusConnection(MessagingFactory messagingFactory, TopicClient topicClient)
        {           
            NamespaceManager namespaceManager = CreateNamespaceManager();
           // if()
           DeleteTopicsAndSubscriptions(namespaceManager);
            CreateTopicsAndSubscriptions(namespaceManager);           
        }

        public static void SendLoginEvent(TopicClient topicClient, NgpEvent data)
        {
            using (BrokeredMessage message = new BrokeredMessage())
            {
                message.CorrelationId = data.locationId;
                message.Properties.Add("EventType", data.eventType);
                message.Properties.Add("Username", data.userName);
                message.Properties.Add("EventName", data.eventName);
                message.Properties.Add("EventTime", data.eventTime);
                message.Properties.Add("LogTime", data.logTime);
                message.Properties.Add("UserSessionId", data.userSessionId);
                topicClient.Send(message);
            }

        }

        public static void SendTransactionsEvent(TopicClient topicClient, NgpEvent data)
        {
            using (BrokeredMessage message = new BrokeredMessage())
            {
                message.CorrelationId = data.locationId;
                message.Properties.Add("EventType", data.eventType);
                message.Properties.Add("AirlineId", data.airlineId);
                message.Properties.Add("DevName", data.devName);
                message.Properties.Add("EventName", data.eventName);
                message.Properties.Add("EventTime", data.eventTime);
                message.Properties.Add("DevType", data.devType);
                message.Properties.Add("UserSessionId", data.userSessionId);
                topicClient.Send(message);
            }

        }

        public static void CreateTopicsAndSubscriptions(NamespaceManager namespaceManager)
        {
            Console.WriteLine("\nCreating a topic and 1 subscriptions.");

            // Create a topic and 3 subscriptions.
            TopicDescription topicDescription = namespaceManager.CreateTopic(TopicName);
           // TopicDescription topicDescription1 = namespaceManager.create
            Console.WriteLine("Topic created.");


            //  Create a subscription that'll receive all orders which have color "blue" and quantity 10. = "",
            //  namespaceManager.CreateSubscription(topicDescription.Path, SubsNameColorBlueSize10Orders, new SqlFilter("EventName = 'Logon'"));
            //  namespaceManager.CreateSubscription(topicDescription.Path, SubsNameColorBlueSize10Orders, new TrueFilter());
            //  Console.WriteLine("Subscription {0} added with filter definition \"color = 'blue' AND quantity = 10\".", SubsNameColorBlueSize10Orders);


            // Create a subscription for all messages sent to topic.
            namespaceManager.CreateSubscription(topicDescription.Path, SubsNameAllMessages, new TrueFilter());
            Console.WriteLine("Subscription {0} added with filter definition set to TrueFilter.", SubsNameAllMessages);

            // Create a subscription that'll receive all high priority orders.
            // namespaceManager.CreateSubscription(topicDescription.Path, SubsNameHighPriorityOrders, new CorrelationFilter("QA74GTT002"));
            // Console.WriteLine("Subscription {0} added with correlation filter definition \"high\".", SubsNameHighPriorityOrders);

            Console.WriteLine("Create completed.");
        }

        public static void DeleteTopicsAndSubscriptions(NamespaceManager namespaceManager)
        {
            Console.WriteLine("\nDeleting topic and subscriptions from previous run if any.");

            try
            {
                namespaceManager.DeleteTopic(TopicName);
            }
            catch (MessagingEntityNotFoundException)
            {
                Console.WriteLine("No topic found to delete.");
            }

            Console.WriteLine("Delete completed.");
        }

        public static void ReceiveAllMessagesFromSubscripions(MessagingFactory messagingFactory)
        {
            // Receive message from 3 subscriptions.
           // ReceiveAllMessageFromSubscription(messagingFactory, SubsNameColorBlueSize10Orders);
            ReceiveAllMessageFromSubscription(messagingFactory, SubsNameAllMessages);
         //   ReceiveAllMessageFromSubscription(messagingFactory, SubsNameHighPriorityOrders);
        }

       public  static void ReceiveAllMessageFromSubscription(MessagingFactory messagingFactory, string subsName)
        {
            int receivedMessages = 0;

            // Create subscription client.
            SubscriptionClient subsClient =
                messagingFactory.CreateSubscriptionClient(TopicName, subsName, ReceiveMode.ReceiveAndDelete);

            // Create a receiver from the subscription client and receive all messages.
            Console.WriteLine("\nReceiving messages from subscription {0}.", subsName);

            while (true)
            {
                var r = subsClient.Receive();
                var r2 = r.GetBody<string>();
                BrokeredMessage receivedMessage;
                receivedMessage = subsClient.Receive(TimeSpan.FromSeconds(10));
                if (receivedMessage != null)
                {
                    var s = receivedMessage.CorrelationId;
                    var s1 = receivedMessage.Properties["EventType"];
                    
                    //receivedMessage.Dispose();
                    receivedMessages++;
                }
                else                
                    // No more messages to receive.
                    break;
               
            }

            Console.WriteLine("Received {0} messages from subscription {1}.", receivedMessages, subsClient.Name);
        }

        public static NamespaceManager CreateNamespaceManager()
        {
            return NamespaceManager.CreateFromConnectionString(ServiceBusConnectionString);
        }

        public static MessagingFactory CreateMessagingFactory()
        {
            return MessagingFactory.CreateFromConnectionString(ServiceBusConnectionString);
        }

        public static TopicClient CreateTopicClient(MessagingFactory messageFactory)
        {
            return messageFactory.CreateTopicClient(TopicName);
        }
    }
}
