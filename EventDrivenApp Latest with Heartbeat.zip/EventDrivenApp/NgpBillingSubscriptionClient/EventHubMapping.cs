﻿using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Microsoft.Azure.EventHubs;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NgpBillingSubscriptionClient
{
   public class EventHubMapping
    {
        
        #region Fields
        static string ServiceBusConnectionString = ConfigurationManager.AppSettings["Microsoft.ServiceBus.ConnectionString"];
        static string TopicName = ConfigurationManager.AppSettings["TopicName"];
        static string SubsNameAllMessages = ConfigurationManager.AppSettings["SubsNameAllMessages"];
        static string SubsNameColorBlueSize10Orders = ConfigurationManager.AppSettings["SubsNameColorBlueSize10Orders"];
        static string SubsNameHighPriorityOrders = ConfigurationManager.AppSettings["SubsNameHighPriorityOrders"];

        #endregion


        public static void ReceiveAllMessagesFromSubscripions(MessagingFactory messagingFactory)
        {
            // Receive message from 1 subscriptions.            
            ReceiveAllMessageFromSubscription(messagingFactory, SubsNameAllMessages);
            
        }

        public static void ReceiveAllMessageFromSubscription(MessagingFactory messagingFactory, string subsName)
        {

            PublishEventsToEventHub.SetEventHubConnectionString();

            int receivedMessages = 0;

            // Create subscription client.
            SubscriptionClient subsClient =
                messagingFactory.CreateSubscriptionClient(ConfigurationManager.AppSettings["TopicName"], subsName, ReceiveMode.ReceiveAndDelete);

            // Create a receiver from the subscription client and receive all messages.
            Console.WriteLine("\nReceiving messages from subscription {0}.", subsName);

            while (true)
            {               
                BrokeredMessage receivedMessage;
                receivedMessage = subsClient.Receive(TimeSpan.FromSeconds(10));
                if (receivedMessage != null)
                {
                    if (receivedMessage.Properties["EventName"].ToString().ToLower() == "logon")
                    {
                        LogOn logon = new LogOn()
                        {
                            userSessionId = receivedMessage.Properties["UserSessionId"].ToString(),
                            eventName= receivedMessage.Properties["EventName"].ToString(),
                            eventType= receivedMessage.Properties["EventType"].ToString(),
                            eventTime= receivedMessage.Properties["EventTime"].ToString(),
                            locationId= receivedMessage.CorrelationId,
                            userName= receivedMessage.Properties["Username"].ToString(),
                            logTime= receivedMessage.Properties["LogTime"].ToString()
                        };
                        PublishEventsToEventHub.SendJsonObjectToEventHub(logon);

                    }
                    else if (receivedMessage.Properties["EventName"].ToString().ToLower() == "transaction")
                    {
                        EventName eventName = new EventName()
                        {
                            locationId = receivedMessage.CorrelationId,
                            airlineId = receivedMessage.Properties["AirlineId"].ToString(),
                            devName = receivedMessage.Properties["DevName"].ToString(),
                            devType = receivedMessage.Properties["DevType"].ToString(),
                            eventTime = receivedMessage.Properties["EventTime"].ToString(),                            
                            eventName = receivedMessage.Properties["EventName"].ToString(),
                            eventType = receivedMessage.Properties["EventType"].ToString(),
                            userSessionId= receivedMessage.Properties["UserSessionId"].ToString()
                        };
                        PublishEventsToEventHub.SendJsonObjectToEventHub(eventName);
                    }                  

                    //receivedMessage.Dispose();
                    receivedMessages++;
                }
                else
                    // No more messages to receive.
                    break;
            }
            Console.WriteLine("Received {0} messages from subscription {1}.", receivedMessages, subsClient.Name);
        }

        public static NamespaceManager CreateNamespaceManager()
        {
            return NamespaceManager.CreateFromConnectionString(ServiceBusConnectionString);
        }

        public static MessagingFactory CreateMessagingFactory()
        {
            return MessagingFactory.CreateFromConnectionString(ServiceBusConnectionString);
        }

        public static TopicClient CreateTopicClient(MessagingFactory messageFactory)
        {
            return messageFactory.CreateTopicClient(TopicName);
        }
    }
}
