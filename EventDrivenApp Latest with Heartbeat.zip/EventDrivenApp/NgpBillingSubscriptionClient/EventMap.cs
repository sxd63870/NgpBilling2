﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NgpBillingSubscriptionClient
{
    public class EventName
    {        
        public string locationId;
        public string label;
        public string devName;
        public string devType;
        public string userSessionId;
        public string eventTime;
        public string eventType;
        public string eventName;        
        public string airlineId;
    }
    public class LogOn
    {
        public string userName;
        public string locationId;
        public string userSessionId;
        public string eventTime;
        public string logTime;
        public string eventType;
        public string eventName;
    }
}
