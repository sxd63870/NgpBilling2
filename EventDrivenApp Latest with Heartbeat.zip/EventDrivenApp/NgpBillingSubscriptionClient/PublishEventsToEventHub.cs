﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.EventHubs;
using System.Configuration;
using Newtonsoft.Json;

namespace NgpBillingSubscriptionClient
{
    public class PublishEventsToEventHub
    {
        private static EventHubClient eventHubClient;
        private static string EhConnectionString = ConfigurationManager.AppSettings["EventHubConnectionString"];
        private static string EhEntityPath = ConfigurationManager.AppSettings["EventHubName"];

        public static void SetEventHubConnectionString()
        {
            var connectionStringBuilder = new EventHubsConnectionStringBuilder(EhConnectionString)
            {
                EntityPath = EhEntityPath
            };
            eventHubClient = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());
        }

        public static void SendLogonEvent(LogOn logon)
        {
            var serialisedString = JsonConvert.SerializeObject(logon);
            EventData data = new EventData(Encoding.UTF8.GetBytes(serialisedString));
            eventHubClient.SendAsync(data);
        }

        public static void SendTransactionEvent(EventName eventName)
        {
            var serialisedString = JsonConvert.SerializeObject(eventName);
            EventData data = new EventData(Encoding.UTF8.GetBytes(serialisedString));
        }

        /// <summary>
        ///  Sends Json Object to EventHub Namespace
        /// </summary>
        /// <param name="eventName"></param>
        public static void SendJsonObjectToEventHub(Object eventName)
        {
            var serialisedString = JsonConvert.SerializeObject(eventName);
            EventData data = new EventData(Encoding.UTF8.GetBytes(serialisedString));
            eventHubClient.SendAsync(data);
        }
    }
 }
