﻿using System.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using Microsoft.Azure.EventHubs;
using System.Text;
using Newtonsoft.Json;
using System.Configuration;
using System.Threading;
using System.Linq.Expressions;
using Microsoft.ServiceBus.Messaging;
using Microsoft.ServiceBus;
using System.IO;

namespace EventDrivenApp
{

    public partial class MainWindow : Window
    {
        // private static EventHubClient eventHubClient;
        private readonly string EhConnectionString = ConfigurationManager.AppSettings["EventHubConnectionString"];
        private readonly string EhEntityPath = ConfigurationManager.AppSettings["EventHubName"];
        bool stopthread = false;
        Thread t1;
        string guidid;
        private int countATB;
        private int countBTP;
        private int countLSR;
        private int countMSR;
        private string logontime;
        private string logofftime;
        List<String> DeviceNames = new List<string>(new string[] { "ATB", "BTP", "LSR", "MSR" });

        #region Fields      
        TopicClient topicClient;
        MessagingFactory messagingFactory;
        #endregion

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Wksid.Content = "Location/Workstation ID: " + Environment.MachineName;
        }

        public void btnlogin_Click(object sender, RoutedEventArgs e)
        {
            messagingFactory = ServiceBusMapping.CreateMessagingFactory();
            topicClient = ServiceBusMapping.CreateTopicClient(messagingFactory);
            ServiceBusMapping.EnableServiceBusConnection(messagingFactory, topicClient);
            var date = DateTime.Now;
            guidid = Environment.MachineName + "." + date.ToString("o");
            NgpEvent ngpLogin = new NgpEvent()
            {
                userSessionId = guidid,
                eventName = "Logon",
                eventType = "User",
                eventTime = DateTime.Now.ToString("hh:mm:ss.f"),
                locationId = Environment.MachineName,
                userName = "User1",
                devName = "logon",
                logTime = DateTime.Now.ToString("hh:mm:ss.f")
            };
            ServiceBusMapping.SendLoginEvent(topicClient, ngpLogin);

            logontime = ngpLogin.eventTime;
            var serialisedString = JsonConvert.SerializeObject(ngpLogin);
            countATB = 0; countBTP = 0; countLSR = 0; countMSR = 0;
            logbox.Items.Add("Logon---" + serialisedString);
            logbox.Items.Add("ATB Count" + countATB + " BTP Count " + countBTP + " MSR Count " + countMSR + " LSR Count " + countLSR);

            btnlogin.IsEnabled = false;
            btnlogoff.IsEnabled = true;
            btnHeartBeat.IsEnabled = true;
            btnTriggerEvents.IsEnabled = true;
            

            //stopthread = true;
            //t1 = new Thread(TriggerEvents);
            //t1.Start(this);
        }

        public void TriggerEvents(object threadstate)
        {
            MainWindow f1 = (MainWindow)threadstate;
            while (stopthread)
            {
                var date = DateTime.Now;
                NgpEvent ngpLogin = new NgpEvent()
                {
                    locationId = Environment.MachineName,
                    airlineId = "SITA",
                    devName = RandomDevNames(),
                    devType = "11",
                    eventTime = DateTime.Now.ToString("hh:mm:ss.f"),
                    eventName = "Transaction",
                    eventType = "MediaPrinted",
                    userSessionId = guidid
                };

                ServiceBusMapping.SendTransactionsEvent(topicClient, ngpLogin);
                var serialisedString = JsonConvert.SerializeObject(ngpLogin);
                this.Dispatcher.Invoke(() =>
                {
                    logbox.Items.Add(ngpLogin.eventType + "---" + serialisedString);
                });
                Thread.Sleep(2000);
            }
        }


       
        public string RandomDevNames()
        {        
            Random rand = new Random();
            int rPos = rand.Next(DeviceNames.Count);
            string dName = DeviceNames[rPos];
            var intvalue = dName == "ATB" ? countATB++ : dName == "BTP" ? countBTP++ : dName == "LSR" ? countLSR++ : dName == "MSR" ? countMSR++ : 0;           
            return dName;
        }

        private void btnlogoff_Click(object sender, RoutedEventArgs e)
        {
            stopthread = false;
            t1.Abort();
            //Thread.Sleep(40000);
            btnlogin.IsEnabled = true;
            var date = DateTime.Now;           
            NgpEvent ngpLogin = new NgpEvent()
            {
                userSessionId = guidid,
                eventName = "Logoff",
                eventType = "User",
                eventTime = DateTime.Now.ToString("hh:mm:ss.f"),
                locationId = Environment.MachineName,
                userName = "User1",
                devName = "Logoff",
                logTime = DateTime.Now.ToString("hh:mm:ss.f")
            };
            ServiceBusMapping.SendLoginEvent(topicClient, ngpLogin);
            logofftime = ngpLogin.eventTime;
            var serialisedString = JsonConvert.SerializeObject(ngpLogin);
            logbox.Items.Add("Logoff---" + serialisedString);
            writeText(countATB, countBTP, countMSR, countLSR);
            btnlogoff.IsEnabled = false;
            btnHeartBeat.IsEnabled = false;
            btnTriggerEvents.IsEnabled = false;
        }

        private void writeText(int countATB, int countBTP, int countMSR, int countLSR)
        {
            var duration = Convert.ToDateTime(logofftime) - Convert.ToDateTime(logontime);
            //  string destPath = Path.Combine(Application.CurrentDomain.BaseDirectory, "NGPBillingEventCount.txt");
            string devCounts = "UserSessionId-" + guidid + " || Duration-" + duration.TotalSeconds + " || ATB-" + countATB + " || BTP-" + countBTP + " || LSR-" + countLSR + " || MSR-" + countMSR;
            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(@"D:\\BillingEventsCount.txt", true))
            {
                file.WriteLine(devCounts);
            }
        }

        private void btnTriggerEvents_Click(object sender, RoutedEventArgs e)
        {
            btnTriggerEvents.IsEnabled = false;
            stopthread = true;
            t1 = new Thread(TriggerEvents);
            t1.Start(this);
        }

        private void btnHeartBeat_Click(object sender, RoutedEventArgs e)
        {
            if (stopthread)
            {
                btnTriggerEvents.IsEnabled = true;
                stopthread = false;
                t1.Abort();
                HeartBeatEvent();
            }
            else
            {
                HeartBeatEvent();
            }
        }


        public void HeartBeatEvent()
        {
           // MainWindow f1 = (MainWindow)threadstate;
            //while (stopthread)
            //{
                var date = DateTime.Now;
                NgpEvent ngpLogin = new NgpEvent()
                {
                    locationId = Environment.MachineName,
                    airlineId = "SITA",
                    devName = "HeartBeat",
                    devType = "11",
                    eventTime = DateTime.Now.ToString("hh:mm:ss.f"),
                    eventName = "Transaction",
                    eventType = "HeartBeat",
                    userSessionId = guidid
                };

                ServiceBusMapping.SendTransactionsEvent(topicClient, ngpLogin);
                var serialisedString = JsonConvert.SerializeObject(ngpLogin);
                this.Dispatcher.Invoke(() =>
                {
                    logbox.Items.Add(ngpLogin.eventType + "---" + serialisedString);
                });
                Thread.Sleep(2000);
           // }
        }

    }
}
