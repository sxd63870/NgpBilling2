﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventDrivenApp
{
    public class Login
    {   
        public string userName ;
        public string locationId;
        public string userSessionId;
        public string eventTime ;
        public string logTime ;
        public string eventType;
        public string eventName;

    }
   
    public class DevNameEvent
    {
        public string locationId;
        public string label;
        public string devName;
        public string devType;
        public string eventName;
        public string airlineId;
        public string userSessionId ;
        public string eventTime;
        public string eventType;
    }

    public class NgpEvent
    {
        public string userName;
        public string locationId;
        public string userSessionId;
        public string eventTime;
        public string logTime;        
        public string airlineId;
        public string eventName;
        public string eventType;
        public string devName;
        public string devType;
    }
}
