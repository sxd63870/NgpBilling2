﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.ServiceBus.Messaging;
using System.IO;
using System.Runtime.Serialization;
using System.Xml;

namespace ServiceBusWebJobTrigger
{
    // To learn more about Microsoft Azure WebJobs SDK, please see https://go.microsoft.com/fwlink/?LinkID=320976
    class Program
    {
        // Please set the following connection strings in app.config for this WebJob to run:
        // AzureWebJobsDashboard and AzureWebJobsStorage
        static void Main()
        {
            JobHostConfiguration config = new JobHostConfiguration();
            config.UseServiceBus();
            config.UseTimers();
            JobHost host = new JobHost(config);
            host.RunAndBlock();
        }

        public T GetBody<T>(BrokeredMessage brokeredMessage)
        {
            var ct = brokeredMessage.ContentType;
            Type bodyType = Type.GetType(ct, true);

            var stream = brokeredMessage.GetBody<Stream>();
            DataContractSerializer serializer = new DataContractSerializer(bodyType);
            XmlDictionaryReader reader = XmlDictionaryReader.CreateBinaryReader(stream, XmlDictionaryReaderQuotas.Max);
            object deserializedBody = serializer.ReadObject(reader);
            T msgBase = (T)deserializedBody;
            return msgBase;
        }

    }
}
