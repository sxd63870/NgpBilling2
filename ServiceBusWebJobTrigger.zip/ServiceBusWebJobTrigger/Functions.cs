﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.ServiceBus.Messaging;
using System.Runtime.Serialization;
using System.Xml;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Linq;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace ServiceBusWebJobTrigger
{
    public class Functions
    {
        //[Disable("DisableMyTimerJob")]
        //// This function will get triggered/executed when a new message is written 
        //// on an Azure Queue called queue.
        //public static void ProcessQueueMessage([ServiceBusTrigger("inboundqueue")] BrokeredMessage message, TextWriter log)
        //{
        //    log.WriteLine(message);
        //}

        private const string EndpointUrl = "https://ngpbillingdb.documents.azure.com:443/";
        private const string PrimaryKey = "Q5Rmh3IDcASTwfnqdP71iGXdoptBUGeao0ZwrMYsLRrt7N2YKKCb8ZFWWykWtSmYw8SnMoA5bM5u5DQBLMpRoA==";
        private static DocumentClient client;
        private static DocumentCollection ColInstance;

        public Functions()
        {
            client = new DocumentClient(new Uri(EndpointUrl), PrimaryKey);
            GenerateDBCollectino().Wait();

        }


        public static async Task GenerateDBCollectino()
        {
            client = new DocumentClient(new Uri(EndpointUrl), PrimaryKey);
            Database jobDB = new Database() { Id = "ngJobDB" };

            Database DBinstance = await client.CreateDatabaseIfNotExistsAsync(jobDB);

            DocumentCollection jobCol = new DocumentCollection() { Id = "ngJobCollection" };
            jobCol.PartitionKey.Paths.Add("/sessionid");
            ColInstance = await client.CreateDocumentCollectionIfNotExistsAsync(DBinstance.SelfLink, jobCol);

        }

        public static async Task ProcessLogon(BrokeredMessage message)
        {
            string sql = "SELECT * FROM c WHERE c.sessionid = " + message.Properties["userSessionId"].ToString();
            var querySpec = new SqlQuerySpec(sql);
            var query = client.CreateDocumentQuery<BillingOutPut>(ColInstance.SelfLink, new FeedOptions() { MaxItemCount = 1 });
            var resposne = query.Where(x => x.sessionid == message.Properties["userSessionId"].ToString()).Select(x => x.sessionid).AsEnumerable().ToList(); //using Linq
            if (resposne.Count == 0)
            {
                BillingOutPutlogon eventobj = new BillingOutPutlogon();
                eventobj.sessionid = message.Properties["userSessionId"].ToString();
                eventobj.LocationId = message.CorrelationId;
                eventobj.loginTime = message.Properties["eventTime"].ToString();
                eventobj.duration = "Still In Progress";
                eventobj.item = null;
                string json = JsonConvert.SerializeObject(eventobj);
                JObject jobject = JObject.Parse(json);
                await client.CreateDocumentAsync(ColInstance.SelfLink, eventobj);

            }

        }

        public static async Task ProcessLogoff(BrokeredMessage message)
        {
            var returnobject = client.CreateDocumentQuery<BillingOutPut>(ColInstance.DocumentsLink).Where(d => d.sessionid == message.Properties["UserSessionID"].ToString())
                           .AsEnumerable().FirstOrDefault();

            BillingOutPutlogon eventobj = new BillingOutPutlogon();
            eventobj.sessionid = returnobject.sessionid;
            eventobj.LocationId = returnobject.LocationId;
            eventobj.loginTime = returnobject.loginTime;            
            eventobj.duration = (Convert.ToDateTime(message.Properties["eventTime"]) - Convert.ToDateTime(returnobject.loginTime)).TotalSeconds.ToString();
            eventobj.item = new EventName[returnobject.item.Count()];
            for (int i = 0; i < returnobject.item.Count(); i++)
            {
                eventobj.item[i] = returnobject.item[i];
            }
            var documentUri = UriFactory.CreateDocumentUri("ngJobDB", "ngJobCollection", returnobject.sessionid);
            await client.DeleteDocumentAsync(returnobject.SelfLink);
            await client.CreateDocumentAsync(ColInstance.SelfLink, eventobj);
        }


        public static void ProcessQueueMessage([ServiceBusTrigger("inboundqueue")] BrokeredMessage message, TextWriter log)
        {
            log.WriteLine(message);
        }

        public static async Task SBTopicListener1(
           [ServiceBusTrigger("ngprequests", "NGPAllRequests")] BrokeredMessage message,
           TextWriter log)
        {
            try
            {

                GenerateDBCollectino().Wait();
                if (message.Properties["EventName"].ToString().ToLower() == "Logon".ToLower())
                {
                    ProcessLogon(message).Wait();
                    return;
                }
                if (message.Properties["EventName"].ToString().ToLower() == "Logoff".ToLower())
                {
                    ProcessLogoff(message).Wait();
                    return;
                }

                // IEnumerable<BillingOutPut> document = client.CreateDocumentQuery<BillingOutPut>(ColInstance.SelfLink).ToList();
                // var SessionRecord = client.CreateDocumentQuery<BillingOutPut>(ColInstance.DocumentsLink).Where(d => d.sessionid == message.Properties["UserSessionID"].ToString()).AsEnumerable().FirstOrDefault();

                var returnobject = client.CreateDocumentQuery<BillingOutPut>(ColInstance.DocumentsLink).Where(d => d.sessionid == message.Properties["UserSessionID"].ToString())
                             .AsEnumerable().FirstOrDefault();

                if (returnobject == null)
                {
                    return;
                }
                BillingOutPutlogon eventobj = new BillingOutPutlogon();
                eventobj.sessionid = returnobject.sessionid;
                eventobj.LocationId = returnobject.LocationId;
                eventobj.loginTime = returnobject.loginTime;
                eventobj.duration = (Convert.ToDateTime(message.Properties["eventTime"]) - Convert.ToDateTime(returnobject.loginTime)).TotalSeconds.ToString();
                if (returnobject.item == null)
                {
                    EventName evname = new EventName();
                    evname.DevName = message.Properties["devName"].ToString();
                    evname.Eventcount = 1.ToString();

                    var documentUri = UriFactory.CreateDocumentUri("ngJobDB", "ngJobCollection", returnobject.sessionid);
                    await client.DeleteDocumentAsync(returnobject.SelfLink);

                    evname.DevName = message.Properties["devName"].ToString();
                    evname.Eventcount = 1.ToString();
                    eventobj.item = new EventName[1];
                    eventobj.item[0] = evname;
                    await client.CreateDocumentAsync(ColInstance.SelfLink, eventobj);
                }
                else
                {
                    eventobj.item = new EventName[returnobject.item.Count()];
                    for (int i = 0; i < returnobject.item.Count(); i++)
                    {
                        eventobj.item[i] = returnobject.item[i];
                    }
                    EventName eventname = new EventName();
                    var query = returnobject.item.Where(x => x.DevName == message.Properties["devName"].ToString()).FirstOrDefault();
                    if (query == null)
                    {
                        eventname.DevName = message.Properties["devName"].ToString();
                        eventname.Eventcount = 1.ToString();
                        Array.Resize<EventName>(ref eventobj.item, eventobj.item.Count() + 1);
                        eventobj.item[eventobj.item.Count()-1] = eventname;
                    }
                    else
                    {
                        for (int i = 0; i < eventobj.item.Count(); i++)
                        {
                            if(query.DevName == eventobj.item[i].DevName)
                            {
                                eventobj.item[i].Eventcount = (int.Parse(eventobj.item[i].Eventcount) + 1).ToString();
                            }
                        }
                    }
                   


                   
                    var documentUri = UriFactory.CreateDocumentUri("ngJobDB", "ngJobCollection", returnobject.sessionid);
                    await client.DeleteDocumentAsync(returnobject.SelfLink);
                    await client.CreateDocumentAsync(ColInstance.SelfLink, eventobj);
                }
                log.WriteLine("SBTopicListener1: " + message.Properties["EventName"].ToString());

            }
            catch (Exception ex)
            {
                log.WriteLine(ex.Message);
            }

        }

        public static T GetBody<T>(BrokeredMessage brokeredMessage)
        {
            var ct = brokeredMessage.ContentType;
            Type bodyType = Type.GetType(ct, true);

            var stream = brokeredMessage.GetBody<Stream>();
            DataContractSerializer serializer = new DataContractSerializer(bodyType);
            XmlDictionaryReader reader = XmlDictionaryReader.CreateBinaryReader(stream, XmlDictionaryReaderQuotas.Max);
            object deserializedBody = serializer.ReadObject(reader);
            T msgBase = (T)deserializedBody;
            return msgBase;
        }
    }
}
