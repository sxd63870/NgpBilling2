﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventDrivenApp
{
    public class Login
    {   
        public string userName ;
        public string locationId;
        public string userSessionId;
        public string eventTime ;
        public string logTime ;
        public string eventType;
        public string eventName;

    }
    public class Logoff
    {
        public string userName ;
        public string locationId;
        public string userSessionId;
        public string eventTime;
        public string logTime;
        public string eventType;
        public string eventName;

    }
    public class DevNameEvent
    {
        public string locationId;
        public string label;
        public string devName;
        public string devType;
        public string eventName;
        public string airlineId;
        public string userSessionId ;
        public string eventTime;
        public string eventType;

    }


    //public class UserIdle
    //{
       
    //    public string locationId = "1";
    //    public string usersessionid = "session";
    //    public string timespan = "timespan";
    //    public string EventType = "EventType";

    //}
    //public class UserActive
    //{
       
    //    public string locationId = "1";
    //    public string usersessionid = "session";
    //    public string timespan = "timespan";
    //    public string EventType = "EventType";

    //}
    
    //public class HeartBeat
    //{

    //    public string locationid = "1";
    //    public string usersessionid = "session";
    //    public string timespan = "timespan";
    //    public string EventType = "EventType";

    //}

    //public class AppStart
    //{

    //    public string locationid = "1";
    //    public string airlineid = "1";
    //    public string usersessionid = "session";
    //    public string timespan = "timespan";
    //    public string EventType = "EventType";

    //}

    //public class AppStop
    //{

    //    public string locationid = "1";
    //    public string airlineid = "1";
    //    public string usersessionid = "session";
    //    public string timespan = "timespan";
    //    public string EventType = "EventType";

    //}

    //public class AppinFocus
    //{

    //    public string locationid = "1";
    //    public string airlineid = "1";
    //    public string usersessionid = "session";
    //    public string timespan = "timespan";
    //    public string EventType = "EventType";

    //}

    //public class Appoutoffocus
    //{

    //    public string locationid = "1";
    //    public string airlineid = "1";
    //    public string usersessionid = "session";
    //    public string timespan = "timespan";
    //    public string EventType = "EventType";

    //}

    //public class Midnight
    //{

    //    public string locationid = "1";
      
    //    public string usersessionid = "session";
    //    public string timespan = "timespan";
    //    public string EventType = "EventType";

    //}
    //public class ProcessBagData
    //{
    //    public int locationid =1;
    //    public string label = "label";
    //    public string airlineid = "airlineid";
    //    public string Logicdevicetype = "airlineid";
    //    public string usersessionid = "airlineid";
    //    public string timespan;
    //    public string eventtype = "ProcessBagData";
    //}

    //public class ProcessMagneticCardData
    //{
    //    public int locationid = 1;
    //    public string label = "label";
    //    public string airlineid = "airlineid";
    //    public string Logicdevicetype = "airlineid";
    //    public string usersessionid = "airlineid";
    //    public string timespan;
    //    public string eventtype = "ProcessMagneticCardData";
    //}
    //public class ProcessTravelDocumentData
    //{
    //    public int locationid = 1;
    //    public string label = "label";
    //    public string airlineid = "airlineid";
    //    public string Logicdevicetype = "airlineid";
    //    public string usersessionid = "airlineid";
    //    public string timespan ;
    //    public string eventtype = "ProcessTravelDocumentData";
    //}

    //public class ProcessBoardingPassData
    //{
    //    public int locationid = 1;
    //    public string label = "label";
    //    public string airlineid = "airlineid";
    //    public string Logicdevicetype = "airlineid";
    //    public string usersessionid = "airlineid";
    //    public string timespan;
    //    public string eventtype = "ProcessBoardingPassData";
    //}
}
