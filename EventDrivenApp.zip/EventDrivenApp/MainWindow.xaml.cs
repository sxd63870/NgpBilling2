﻿using System.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using Microsoft.Azure.EventHubs;
using System.Text;
using Newtonsoft.Json;
using System.Configuration;
using System.Threading;
using System.Linq.Expressions;
using Microsoft.ServiceBus.Messaging;
using Microsoft.ServiceBus;

namespace EventDrivenApp
{

    public partial class MainWindow : Window
    {
       // private static EventHubClient eventHubClient;
        private readonly string EhConnectionString = ConfigurationManager.AppSettings["EventHubConnectionString"]; 
        private readonly string EhEntityPath = ConfigurationManager.AppSettings["EventHubName"];
        bool stopthread = false;
        Thread t1;
        string guidid;
        private int countATB;
        private int countBTP;
        private int countLSR;
        private int countMSR;
        private string logontime;
        private string logofftime;

        #region Fields      
        TopicClient topicClient;
        MessagingFactory messagingFactory;
        #endregion

        public MainWindow()
        {
            InitializeComponent();
        }
      
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Wksid.Content = "Location/Workstation ID: " + Environment.MachineName;                 
        }
       
        public void btnlogin_Click(object sender, RoutedEventArgs e)
        {
            messagingFactory = ServiceBusMapping.CreateMessagingFactory();
          // ServiceBusMapping.ReceiveAllMessagesFromSubscripions(messagingFactory);
            topicClient = ServiceBusMapping.CreateTopicClient(messagingFactory);
           ServiceBusMapping.EnableServiceBusConnection(messagingFactory,topicClient);

            var date = DateTime.Now;           
            guidid = Environment.MachineName + "." + date.ToString("o");
            Login login = new Login()
            {
                userSessionId = guidid,
                eventName = "Logon",
                eventType = "User",
                eventTime = DateTime.Now.ToString("hh:mm:ss.f"),
                locationId = Environment.MachineName,
                userName = "User1",
                logTime = DateTime.Now.ToString("hh:mm:ss.f")
            };
            ServiceBusMapping.SendLoginEvent(topicClient, login);

            logontime = login.eventTime;
            var serialisedString = JsonConvert.SerializeObject(login);            
            countATB = 0;
            countBTP = 0;
            countLSR = 0;
            countMSR = 0;
            logbox.Items.Add("Logon---" + serialisedString);
            logbox.Items.Add("ATB Count" + countATB + " BTP Count " + countBTP + " MSR Count " + countMSR + " LSR Count " + countLSR);

            btnlogoff.IsEnabled = true;
            btnlogin.IsEnabled = false;
            stopthread = true;
            t1 = new Thread(TriggerEvents);
            t1.Start(this);
        }     

             

        /**
         * Triggering events to Event Hub(As of Now in this Transcation Events)
         * 
         * */
        public void TriggerEvents(object threadstate)
        {            
            MainWindow f1 = (MainWindow)threadstate;
            while (stopthread)
            {
                var date = DateTime.Now;

                DevNameEvent devevent = new DevNameEvent()
                {
                    locationId = Environment.MachineName,
                    airlineId = "SITA",
                    devName = RandomDevNames(),
                    devType = "11",
                    eventTime = DateTime.Now.ToString("hh:mm:ss.f"),
                    eventName = "Transaction",
                    eventType = "MediaPrinted",
                    userSessionId = guidid

                };
                ServiceBusMapping.SendTransactionsEvent(topicClient, devevent);
                var serialisedString = JsonConvert.SerializeObject(devevent);
                //EventData data = new EventData(Encoding.UTF8.GetBytes(serialisedString));
                //eventHubClient.SendAsync(data);
                this.Dispatcher.Invoke(() =>
                {
                    logbox.Items.Add(devevent.eventType + "---" + serialisedString);
                });               
                Thread.Sleep(2000);
            }
        }


        /*Generate Random Device Names*/
        public string RandomDevNames()
        {
            List<String> DeviceNames = new List<string>();

            DeviceNames.Add("ATB");
            DeviceNames.Add("BTP");
            DeviceNames.Add("LSR");
            DeviceNames.Add("MSR");

            Random rand = new Random();
            int rPos = rand.Next(DeviceNames.Count);
            string dName = DeviceNames[rPos];
            if (dName == "ATB")
                countATB++;
            else if (dName == "BTP")
                countBTP++;
            else if (dName == "LSR")
                countLSR++;
            else if (dName == "MSR")
                countMSR++;
            return dName;

        }

        /**
         * Log Off Event
         * **/
        private void btnlogoff_Click(object sender, RoutedEventArgs e)
        {
            stopthread = false;
            t1.Abort();
            btnlogin.IsEnabled = true;
            var date = DateTime.Now;
            Login login = new Login()
            {
                userSessionId = guidid,
                eventName = "Logoff",
                eventType = "User",
                eventTime = DateTime.Now.ToString("hh:mm:ss.f"),
                locationId = Environment.MachineName,
                userName = "User1",
                logTime = DateTime.Now.ToString("hh:mm:ss.f")
            };
            ServiceBusMapping.SendLoginEvent(topicClient,login);

           // ServiceBusMapping.ReceiveAllMessagesFromSubscripions(messagingFactory);
           // messagingFactory.Close();

            logofftime = login.eventTime;
            var serialisedString = JsonConvert.SerializeObject(login);            
            logbox.Items.Add("Logoff---" + serialisedString);            
            writeText(countATB, countBTP, countMSR, countLSR);
            btnlogoff.IsEnabled = false;
        }

        private void writeText(int countATB, int countBTP, int countMSR, int countLSR)
        {
            var duration = Convert.ToDateTime(logofftime) - Convert.ToDateTime(logontime);          
            string devCounts = "UserSessionId-" + guidid + " || Duration-" + duration.TotalSeconds + " || ATB-" + countATB + " || BTP-" + countBTP + " || LSR-" + countLSR + " || MSR-" + countMSR;
            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(@"D:\\BillingEventsCount.txt", true))
            {
                file.WriteLine(devCounts);
            }
        }                 

    }
}
